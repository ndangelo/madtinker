---
title: Annual Report Design
slug: annual-report-design
date: '2024-01-02'
modified: '2024-01-02'
status: published
wordpress_id: 64332
source_url: https://nuggetofjoy.com/annual-report-design/
author: admin
categories:
- Projects
tags: []
migration:
  format: hybrid-markdown
  original_html: original-html/64332.html
  post_css: null
  needs_review: false
---

#### PROJECT BRIEF


Student will design and print an annual report. The final artifact should combine graphics, photos, content and data to chronicle their chosen companies' corporate activities and financial and operational information. The work will be based on the design decisions asserted in Project One of the semester (client rebrand: logo, brand guidelines, identity system, and ephemera)


#### LEARNING OBJECTIVES


• Technical Skills/Use of **InDesign**


• Content Delivery, Sequence, and Pacing in Long-Format Design


• Critical & Conceptual Thinking


• Information Design


#### DELIVERABLES


Students submitted a packaged InDesign file and a printed Annual Report booklet for grading.


#### READINGS/RESOURCES


I collected several Annual Reports to show to the students. Each Annual Report was studied and critiqued as an in-class discussion. This helped students become more familiar with the elements of an Annual Report and understand the project's expectations.


#### REFLECTIONS


For the most part, this functioned as an introduction to long-format design for our students. In preparing them for the challenges of long-format design, the students went through a series of in-class assignments that went through the tools of InDesign. I had students screen-record their process in InDesign to demonstrate they had a clear understanding of the technical requirements of the software.


Moving forward, I would provide more examples and in-class exercises of pace and sequencing in other publications outside annual reports. It seemed the more difficult concept for students to grasp.


[![Example](https://teachingresource.aiga.org/wp-content/uploads/2019/04/Screen-Shot-2019-04-16-at-11.44.13-AM-1024x641.png)](https://teachingresource.aiga.org/wp-content/uploads/2019/04/Screen-Shot-2019-04-16-at-11.44.13-AM.png)

Bradley Platz, Atomic Omelette Annual Report


[![Example](https://teachingresource.aiga.org/wp-content/uploads/2019/04/Screen-Shot-2019-04-16-at-11.45.29-AM-1024x637.png)](https://teachingresource.aiga.org/wp-content/uploads/2019/04/Screen-Shot-2019-04-16-at-11.45.29-AM.png)

Sierra Lutz, Star Orthodontics Annual Report


[![Example](https://teachingresource.aiga.org/wp-content/uploads/2019/04/Screen-Shot-2019-04-16-at-11.48.11-AM-1024x638.png)](https://teachingresource.aiga.org/wp-content/uploads/2019/04/Screen-Shot-2019-04-16-at-11.48.11-AM.png)

Catherine Derbala, Members First Annual Report


[![Example](https://teachingresource.aiga.org/wp-content/uploads/2019/04/Screen-Shot-2019-04-16-at-11.46.41-AM-1024x636.png)](https://teachingresource.aiga.org/wp-content/uploads/2019/04/Screen-Shot-2019-04-16-at-11.46.41-AM.png)

Rhiannon Howard, Popsicle Annual Report
