---
title: 7 of the Best Social Media Campaigns 
slug: 7-of-the-best-social-media-campaigns
date: '2021-11-08'
modified: '2021-11-08'
status: published
wordpress_id: 57999
source_url: https://nuggetofjoy.com/7-of-the-best-social-media-campaigns/
author: admin
categories:
- Projects
tags: []
migration:
  format: hybrid-markdown
  original_html: original-html/57999.html
  post_css: null
  needs_review: true
---

A social media campaign is coordinated marketing designed to reinforce information or sentiments —about a product, service, or overall brand—through at least one social media platform.


## **7 social media campaign examples to learn from**


## **Coors Light #CouldUseABeer**


**Platforms used:** Twitter


[Coors Light](https://www.coorslight.com/) has had some of the most interesting social media campaigns lately, including their [Clone Machine](https://www.youtube.com/watch?v=mCtkJbNuqL8), which lets users record a 30-second video loop of them looking interested during video conferences so that they can sneak away to grab a beer.


That idea came hot on the heels of their latest social media marketing campaign, #CouldUseABeer. For a limited period of time, Coors Light promised a six-pack to anyone who tweeted at them using the campaign hashtag.


<div class="twitter-tweet twitter-tweet-rendered">MADTINKERBLOCKTOKEN0END</div>


They kept up the giveaway until [they gave away 500,000 beers](https://www.thrillist.com/news/nation/coors-light-free-beer-promo-could-use-a-beer) to grateful customers. The #CouldUseABeer campaign was inspired by another previous social media win for Coors Light. They answered the pleas of a quarantined 93-year-old woman who went viral after she [posted a sign in her window asking for beer](https://wgntv.com/news/pennsylvania-93-year-old-with-i-need-more-beer-sign-gets-her-wish/) during her quarantine.


<div class="twitter-tweet twitter-tweet-rendered">MADTINKERBLOCKTOKEN1END</div>


**Why it worked:**Running a giveaway is a great way to boost brand awareness and stoke positive sentiments for one simple reason: everyone loves free stuff.


But Coors Light already had a starting advantage, after the positive public interest from their quarantine giveaway. That served as a springboard for launching their campaign and gaining even wider recognition.


**What you can learn:**Timing is everything. Coors Light not only offered a promotion that addressed the stress and fatigue of a global epidemic but also leveraged their latest 15 minutes of fame.


## **Hello BC’s #ExploreBCLater**


**Platforms used:** Instagram, Facebook, Twitter


**What Hello BC did:**with [air travel down 95%](https://www.cntraveler.com/story/coronavirus-air-travel-these-numbers-show-the-massive-impact-of-the-pandemic) and nearly everyone canceling their summer vacation plans. It’s hard to spin that into a destination-focused campaign, but provincial tourism authority [Hello BC](https://www.hellobc.com/) hit the mark with their [#ExploreBCLater](https://www.instagram.com/explore/tags/explorebclater/) campaign.


Across all social platforms, Hello BC shared a [message of social responsibility](https://www.facebook.com/watch/?v=234170387735016) in the face of coronavirus, encouraging everyone to stay home and #ExploreBCLater. The campaign was a twist on their [branded hashtag](https://blog.hootsuite.com/how-to-use-hashtags/), #ExploreBC, building on existing brand recognition and usage.


<div class="sbi-embed-wrap">MADTINKERBLOCKTOKEN2END<p></p>
</div>


Along with posts by industry partners, the #ExploreBCLater campaign encouraged travelers to share images and videos from their trips across the province, offering vicarious journeys through social media and keeping these travel destinations top of mind.


So far, the hashtag has been used over 9,500 times on Instagram, with more posts across Twitter and Facebook too.


**Why it worked:**This campaign is fuelled by [user-generated content](https://blog.hootsuite.com/user-generated-content-ugc/) (UGC), which helps your brand build its reputation through the audiences and social media channels of influential users. UGC also helps brands build up their content library by collecting high-quality visual assets from other users and resharing them with permission.


The #ExploreBCLater campaign is also mutually beneficial to travel bloggers, who have been hard-hit by the global pandemic. Participating in the #ExploreBCLater lets them repurpose their existing assets into fresh posts.


When running a social media campaign, it’s always important to offer participants something of value as well.


**What you can learn:**Sometimes, you have to roll with the punches and find a way to adapt to challenging circumstances. This campaign is a great example of turning lemons into lemonade, creating a feel-good campaign that kept audiences engaged and interested in BC as a travel destination while sharing a responsible and caring message.


## **Starbucks #WhatsYourName**


**Platforms used:**Twitter, Instagram, Facebook, YouTube & traditional advertising


**What Starbucks Did did:**In February, Starbucks UK partnered with Mermaids, an organization to support transgender and gender-diverse youth, on the [#WhatsYourName campaign](https://stories.starbucks.com/emea/stories/2020/whatsyourname/).


<iframe allowfullscreen="allowfullscreen" data-mce-fragment="1" frameborder="0" height="360" src="https://www.youtube.com/embed/pcSP1r9eCWw?feature=oembed" title="Starbucks LGBT+ Channel 4 Diversity Award 2019 | Every name’s a story (Extended Version)" width="640"></iframe>


Combining TV advertising and social media engagement, the values-driven campaign focused on Starbucks’ desire to be inclusive toward people of all genders, by honoring their chosen names.


The campaign builds on a well-known aspect of the Starbucks experience—having your name written on the side of your cup—by committing to respect the names that customers want to be called.


<div class="twitter-tweet twitter-tweet-rendered">MADTINKERBLOCKTOKEN4END</div>


<div class="wp-block-group"><!-- wp:freeform -->
<div class="sbi-embed-wrap">MADTINKERBLOCKTOKEN5END<p></p>
</div>
<!-- /wp:freeform --></div>


It’s a pretty heartwarming (and award-winning) campaign, which invited users on social media to use the #WhatsYourName hashtag. They also encouraged people to post photos of their mermaid tail cookie, which raised funds for Mermaids, using the campaign hashtag.


**Why it worked:**This campaign used one of the most traditional advertising methods, a TV spot, to build a buzz on social media. They created a simple, clear campaign hashtag. And they led with their values, which helped this campaign make a real, emotional impact.


**What you can learn:**Many brands steer away from politicized topics, but ultimately, your employees and customers [want you to make the world a better place](https://blog.hootsuite.com/social-media-activism/). Specifically, they want companies to lead on issues of diversity and community.


Sharing campaign messages of inclusivity and respect through #WhatsYourName helped Starbucks rebuild trust and respect with their customers, and showed the world what kind of company they want to be.


## **#DeliveryDigiorno**


<div class="wp-block-embed__wrapper">
https://twitter.com/DiGiorno/status/1176224930511409159?ref_src=twsrc%5Etfw%7Ctwcamp%5Etweetembed%7Ctwterm%5E1176224930511409159%7Ctwgr%5E%7Ctwcon%5Es1_c10&amp;ref_url=https%3A%2F%2Fmarketing.twitter.com%2Fen%2Fsuccess-stories%2Fhow-twitter-helped-digiorno-deliver-during-national-pizza-month
</div>


**Platforms used:**Twitter


**What Digiorno did:**During National Pizza Month 2019 (also known as “October”), Digiorno offered free pizza to customers who tweeted #DeliveryDigiorno.


Confession: I have never eaten Digiorno pizza in my life, but I still know the tagline from years of primetime TV watching in my youth: “It’s not delivery, it’s Digiorno!” The campaign was brilliant because it played on their best-known attribute.


In addition to organic engagement, DiGiorno used promoted tweets and promoted trends to draw attention to their campaign. They also ran a contest asking customers for input on which cities would be chosen for the delivery destinations to stoke interest.


In total, DiGiorno delivered 1,100 pizzas (still frozen, by the way) in five major cities, and accrued [55.3 million impressions for their campaign](https://marketing.twitter.com/na/en/success-stories/how-twitter-helped-digiorno-deliver-during-national-pizza-month). A delicious and clever success.


**Why it worked:**Digiorno took advantage of National Pizza Month, when they knew customers on Twitter would be tweeting (and thinking) about pizza. They combined organic interest and promoted tweets to create an authentic buzz around their activities, and incentivized participation by offering rewards (pizza!) for engaging in the campaign hashtag.


**What you can learn:**What is your brand best known for? Playing off those qualities as DiGiorno did can help you win new fans and charm your current supporters.


Taking advantage of a popular event on social media (like National Pizza Month) can also help you surf the waves of audience interest. But you won’t be the only brand competing for attention, which is why you need to combine a tempting offer and an attention-grabbing concept like DiGiorno did.


## **#DistanceDance with Proctor & Gamble**


**Platforms used:**TikTok


**What they did:**Proctor & Gamble—the consumer goods giant responsible for your toilet paper and toothpaste, probably—partnered with TikTok sensation Charli D’Amelio to urge people to stay home and prevent the spread of coronavirus in March 2020.


<div class="wp-block-embed__wrapper">
https://www.tiktok.com/@charlidamelio/video/6807971434959310085?sender_device=pc&amp;sender_web_id=7027194456300996102&amp;is_from_webapp=v1&amp;is_copy_url=0
</div>


With help from the ad agency Grey, they launched the #DistanceDance on D’Amelio’s channel. TikTok users were urged to record their own version with the campaign hashtag, as [Proctor & Gamble donated to Feeding America for each of the first 3 million videos.](https://www.insider.com/charli-damelio-distance-dance-on-tik-tok-to-drive-donations-2020-3)


It’s an understatement to say the campaign took off. In the first week alone, #DistanceDance garnered [8 billion views and 1.7 million iterations](https://www.prweek.com/article/1679533/p-g-tiktok-grey-difference-distancedance-campaign), with celebrities, sports teams and other big names joining in.


<div class="wp-block-embed__wrapper">
https://www.tiktok.com/@ashleytisdale/video/6809018507393568005
</div>


Currently, [the hashtag has 16 billion views](https://www.tiktok.com/tag/distancedance?lang=en) and growing.


**Why it worked:**[Dance challenges](https://www.thecut.com/2020/03/tiktok-dances-to-learn.html) are the bread and butter of TikTok. Users share simple, original choreography, set to popular songs, that other users can imitate. Teen users are even [getting their parents](https://www.buzzfeednews.com/article/laurenstrapagiel/blinding-lights-tiktok-dance-challenge-parents) into dance challenges.


By understanding TikTok and its audience, the creators of #DistanceDance hit a home run.


**What you can learn:**A [smart influencer partnership](https://blog.hootsuite.com/influencer-marketing/) can take your campaign to incredible heights. D’Amelio is the number-one most-followed influencer on the platform with [over 59 million fans](https://www.tiktok.com/@charlidamelio?lang=en), but you don’t necessarily need to partner with the biggest influencer you can afford. The more important factor is fit: finding an influencer who aligns with your brand values and audience.


Also, many brands have yet to venture into TikTok, despite the fact that the platform is [now the sixth biggest social network](https://blog.hootsuite.com/tiktok-stats/) (and growing). It’s especially [popular among Gen Z](https://adage.com/article/tech/leaked-pitch-deck-reveals-how-tiktok-trying-woo-brands/2205906), with about half of all users between the ages of 18 and 24. So if your brand wants to reach a young, savvy audience, consider the power of TikTok (or maybe even TikTok’s competitor, [Reels](https://blog.hootsuite.com/instagram-reels/)).


## **Spotify #2019Wrapped**


<div class="sbi-embed-wrap">MADTINKERBLOCKTOKEN6END
<p> </p>
</div>


**Platforms used:**Spotify, Instagram, Facebook, Twitter


**What Spotify did:**Since 2017, Spotify has shared year-end data with their users, compiling their most-listened-to songs, albums and artists in [a personalized “Spotify Wrapped” summary](https://newsroom.spotify.com/2019-12-05/spotify-wrapped-2019-reveals-your-streaming-trends-from-2010-to-now/).


For 2019, they went bigger, with a summary of the past decade (2010-2019) showing how users’ listening habits and preferences had evolved. These summary snapshots were provided in shareable image formats, perfect for posting across Twitter, Facebook, and Instagram.


The irresistible nostalgia combined with the fun of personalized data made for an incredibly sharable campaign, which is why your feeds were probably dominated by #SpotifyWrapped posts in December.


Spotify also created personalized summaries for artists, letting them see how many fans they had, countries where their music was streamed, and total hours of streaming time.


**Why it worked:**Users love personalized data—even if some of us (ahem) would be grateful *not*to know how many times we listened to Adele while crying. That’s why you can’t resist a good Buzzfeed quiz or a particularly accurate horoscope.


By offering users fun and insightful data visualizations to share, Spotify essentially created a winning ad campaign and let their users do the work of promoting it. That kind of [social proof](https://blog.hootsuite.com/social-proof/) is hard to beat. The Spotify Wrapped format is so recognizable, it even [became a meme](https://www.instagram.com/p/B5x1lauheQF/).


**What you can learn:**You can recycle a great campaign year over year, if you add some thoughtful updates to keep it interesting. Spotify added new data and insights for 2019, including Wrapped summaries for podcasters, and creating world maps to show users where their music is made:


![Spotify Wrapped annual campaign](http://nuggetofjoy.com/wp-content/uploads/Screen-Shot-2020-08-18-at-5.57.48-PM-39.png)


Tying your campaign to an annual event (like the end of the year) also builds anticipation among your fans, helping it to grow bigger every year.


## **Pantone Color Commentary**


**Platforms used:**Twitter


**What Pantone did:**A one-day campaign overlapping with the [2020 Super Bowl](https://digitalagencynetwork.com/pantone-will-present-its-color-commentary-on-social-media-during-super-bowl/), where Pantone’s Twitter account shared a live play-by-play called [#BigGameColorCommentary](https://twitter.com/hashtag/BigGameColorCommentary).


The campaign was inspired by a colorful coincidence: [for the first time in Super Bowl history, the two teams had the same primary uniform color](https://digitalagencynetwork.com/pantone-will-present-its-color-commentary-on-social-media-during-super-bowl/). In fact, the red hues of the Kansas City Chiefs and the San Francisco 49ers were just one point apart in the Pantone color index.


<div class="wp-block-embed__wrapper">
https://twitter.com/darrenrovell/status/1224091514193764352?ref_src=twsrc%5Etfw
</div>


Live-tweeting along with the big game, Pantone provided a color-coded breakdown of the action.


<div class="wp-block-embed__wrapper">
https://twitter.com/pantone/status/1224168312910811136?ref_src=twsrc%5Etfw
</div>


**Why it worked:**This campaign was fun, original, and made creative use of Pantone’s brand identity as color experts. It created a bridge between sports fans and design aficionados, with accessible posts that anyone could enjoy. The Super Bowl is one of the biggest events of the year, and Pantone found a way to capitalize on that interest in a surprising way.


**What you can learn:**Campaigns can be short and sweet! If you lack the resources (or executive support) to launch a resource-intensive campaign, try something fun and finite to test the waters and see how your audience responds.


Also, don’t limit yourself when looking for a timely opportunity to launch a campaign! No one would have ever put “Pantone” and “football” in the same sentence before, but that unexpected angle was exactly why it worked! Think outside the box and you might just stumble across a brilliant idea.


## **Common elements of successful social media campaigns**


As you probably noticed, these campaigns all looked pretty different from one another. So what makes a social media marketing campaign successful? Here are the key ingredients:


**1. They’re true to the brand**. Each of these campaigns [reflects the brand identity and values](https://blog.hootsuite.com/how-to-build-an-authentic-voice-on-social/) in a way that resonates with their fans. No matter how clever the concept or how big the budget is, a campaign that doesn’t make sense for your brand won’t work.


**2. They’re focused**. Each campaign has a single, simple message at its core: for Spotify, it’s “your year in music.” For Coors Light, it’s “free beer!” Your customers should never be trying to figure out what the point of your campaign is, or be confused about what you are asking them to do. Stick to one goal and one central message per campaign.


**3. They’re trackable.**Each campaign has a distinct hashtag or channel, which means the companies can [measure key indicators of success](https://blog.hootsuite.com/measure-social-media-roi-business/). For an awareness campaign, that might be mentions or shares; for contests, that could be the number of entries. Whatever your campaign goal, make sure you have a plan to evaluate your impact.


**4. They’re unique to each platform.** Broadcasting identical content across every platform is less effort for your social media team, but it looks sloppy.  
Good campaigns have core messages that are tailored to each platform and play on the strengths of that network. User expectations are different on Twitter versus TikTok, and the wrong tone or messaging can be pretty jarring. Make sure you consider your audience on each social network when developing your messaging.


**5. They’re timely.** Every campaign above was responsive to the current events and activities that were top of mind for their audiences.  
Having a [social media content calendar](https://blog.hootsuite.com/how-to-create-a-social-media-content-calendar/) that helps you keep track of annual events, like the Super Bowl (or National Pizza Month) can help you plan for and seize opportunities to make an impact


**6. They’re emotional.** Emotional doesn’t always mean sentimental or tear-jerking (though if you found yourself getting misty during that Starbucks campaign, you’re not alone!). But to be memorable, they should make you feel something when you see them.


A great campaign offers audiences a meaningful and genuine message that they can connect with. Whether you want audiences to feel empowered, nostalgic, delighted, or understood, your campaign should be grounded in a shared sentiment.


**7. They’re original.**To paraphrase Peggy Olson on Mad Men, you should never try to imitate someone else’s successful idea: “[You’ll be second, which is very far from first.](https://twitter.com/MadMenQts/status/586479122903248896)”


Each of these campaigns succeeded because they offered audiences something unique and interesting. Pantone provided a novel take on sports commentary; Proctor & Gamble gave TikTokkers a brand-new dance. Social media users are bombarded by content daily. To stand out, you need to provide something fresh and interesting.


Whether you’re starting from scratch or looking to improve your current social marketing strategy, you need this essential social media template.


The social media strategy template makes it easy to:


- Set social media goals that lead to real business results
- Better target your ideal customer
- Gather intel on the competition so you can stay ahead
- See what’s already working and what’s not
- Create or improve your social media profiles
- Develop a thoughtful content strategy and set a publishing schedule you can stick to
- Track your progress and adjust your plan as needed


## 2. [Social media proposal template](https://www.hootsuite.com/resources/blog/social-media-proposal-template)


<div class="wp-block-image"><figure class="aligncenter"><img alt="preview of social media proposal template" src="http://nuggetofjoy.com/wp-content/uploads/social-media-proposal-template-620x524-20.png"/></figure></div>


This template is for freelance social media professionals and social media agencies.


A social media marketing proposal is a document in which you propose a set of social media marketing services for a potential client. You’ll outline the specifics of the work you propose to do for the client, including a timeline and budget and how you plan to work together.


With the right details in place, you’re well-positioned to establish a good working relationship with a new client.


# How to run a cross-platform social media campaign


### Why you can’t just post the same message across networks


While you may have read the title of this post and said “Easy! Just copy and paste the same content to all my different networks,” it’s my civic duty to tell you that you’re misguided.


Have you ever seen what it looks like when somebody uses an Instagram-level of hashtags on a Facebook post? Or when someone tags somebody else and the tagged person’s username is different on different platforms? Not pretty—or professional.


Every network has a different set of [required specs](https://blog.hootsuite.com/social-media-image-sizes-guide/) for content, so if you’re posting an Instagram image to Twitter the quality might be poor. Not only that, but, as we explain in our post [Stop Posting the Same Message on Social Media (And Do This Instead)](https://blog.hootsuite.com/cross-promote-social-media/), “things like [caption length](https://blog.hootsuite.com/ideal-social-media-post-length/), image formatting, and vocabulary differ by platform. Sharing the exact same post on all of them means you might accidentally end up inviting your followers to retweet you on Facebook or Pin your post on Instagram.” How embarrassing.


It’s also important to make sure you aren’t boring your audience. “You want to do anything to avoid audience fatigue,” Martin explains. “If you’re posting the same content on all of your channels, you risk audience members seeing the exact same thing from you over and over again.” If you’ve ever experienced this from a brand, you know just how annoying it can be.


Instead, think of your campaign as a story you’re telling across different mediums.


You want the story to feel connected and cohesive, *but not repetitive*.


## Tips for running your campaign on 4 key networks


Our social media team has found that each network is best suited for a specific type of content. They share their experiences and insights—along with issues particular to each network—below.


<div class="wp-block-image"><figure class="aligncenter"><img alt="" class="wp-image-182694" src="http://nuggetofjoy.com/wp-content/uploads/CrossPlatform-Blog2018-1-620x282-20.png"/></figure></div>


### Facebook


Once you know who your audience is, it becomes much easier to create content that will resonate with them. For Facebook, our team has found that Facebook users want more storytelling content instead of being continuously served ads. So it’s important to find creative ways to intrigue our audience.


“When it comes to Facebook, our audience wants a story. We can’t simply post something like a stat. It needs to be creative and visual,” Colling explains. “Because of this, we have found that video performs really well on Facebook.”


Facebook is especially useful when it comes to the overall brand awareness aspect of your campaign.


“Facebook allows you to lean on your brand to peak users’ interest,” Wood explains. “It’s a great network for educating and inspiring your following in order for them to take action. Through this, you’re able to build a lasting relationship with your audience and customers.”


**Takeaway:** when designing your campaign, consider using Facebook for storytelling and education-focused posts that contribute to brand awareness objectives, particularly in video form.


### Instagram


Before you share your campaign on Instagram, you need to think about whether it fits into your overall strategy.


Our Hootsuite Instagram feed features user-generated content and lifestyle content, so sharing a campaign post wouldn’t align with our strategy. However, we have found great success sharing our campaigns to Instagram Stories and [IGTV](https://blog.hootsuite.com/instagram-tv/). It’s all about finding what works best for your brand.


“It’s also crucial to understand that it’s likely your audience is viewing your Instagram content on mobile,” Wood explains. “Make sure your campaign content is mobile-friendly and doesn’t require multiple steps or complicated user interfaces to serve your purpose.”


For example, if you’re running an ad on [Instagram Stories](https://blog.hootsuite.com/how-to-use-instagram-stories/) for an upcoming webinar and your audience has to swipe up to register, make sure there aren’t any barriers such as pop-ups or passwords. You want to do everything you can to ensure they are able to fulfill the action without abandoning your site.


**Takeaway:** In a mobile world, it’s important to simplify the process as much as possible for your audience.


### Twitter


The fast-paced and news-focused nature of Twitter means you have to be extra conscious of the campaign content you post there.


“Twitter is very value-driven,” Martin explains. “We’ve found that the Twitter audience responds well to very clear CTAs and direct information.”


If you’re advertising a campaign webinar, Tweet out the key elements of your message—date, time, topic—and leave any teaser info out. The Twitter timeline is jam-packed with content and distracting visuals, so you want to make sure your message doesn’t get lost in the crowd.


Our team has found that social cards (a digital postcard), [GIFs](https://blog.hootsuite.com/how-to-make-gif/), and static images work great for campaigns. Social cards allow your brand to clearly share crucial information in a visually-appealing way, and other images such as GIFs fit in with the way users are interacting with Twitter.


Again, it’s about knowing your audience on the platform. If you’ve seen your followers engage with GIFs in a positive way or notice a boost in webinar sign-ups after sharing social cards, you can take this data and apply it to future campaigns on Twitter.


**Takeaway:** Give your audience the key information they need—right away.


### LinkedIn


When it comes to LinkedIn, your audience is looking for very specific content.


“LinkedIn users are on the network with the goal of improvement,” Colling explains. “They are looking to advance their careers, get expert advice, and learn new things, so it’s important to create campaign content that speaks to these needs.”


Where a video you shared on Facebook might be about brand awareness and feature more storytelling components, you can switch up the video’s main message for your LinkedIn portion of your campaign to show your audience exactly what they’ll learn in your webinar (for example) or why other professionals will be watching the webinar.


FOMO is real on LinkedIn, but with some quick changes to your copy and visual assets, you can easily create content that resonates with your audience there.


**Takeaway:** Focus on posting educational content that helps your audience improve an aspect of their lives—and be clear about why they shouldn’t miss out.
