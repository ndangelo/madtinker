---
title: The Beginner’s Guide to Kerning, Tracking and Leading
slug: the-beginners-guide-to-kerning
date: '2023-01-14'
modified: '2023-01-15'
status: published
wordpress_id: 59765
source_url: https://nuggetofjoy.com/the-beginners-guide-to-kerning/
author: admin
categories:
- 255 Digital Publishing for Graphics &amp; Web
tags: []
migration:
  format: hybrid-markdown
  original_html: original-html/59765.html
  post_css: null
  needs_review: false
---

From: <https://www.indesignskills.com/>


## Find out more about kerning, including what exactly kerning is and how you can apply kerning in your own design work.


---


### What is Kerning?


---


![what is kerning beginners typography letter-spacing how to indesign](http://nuggetofjoy.com/wp-content/uploads/kerning1-1.jpg)


Kerning is the process of increasing or decreasing the space between individual characters, adjusting the position of letters in relation to others. It’s commonly used on prominent pieces of text, such as headlines and logos. Note that tracking, on the other hand, is used to adjust the letter-spacing uniformly over a range of characters ([read more about tracking](https://indesignskills.com/tutorials/letter-spacing-tracking-typography/)).


---


### Why Do Designers Use Kerning?


---


Although the process of tweaking kerning may be very subtle, it can have significant effects on the legibility and overall presentation of text.


![what is kerning beginners typography letter-spacing how to indesign](http://nuggetofjoy.com/wp-content/uploads/2-5.jpg)


Designers kern letters to improve the overall symmetry of a word or phrase, which the default tracking settings provided in the font file may not be able to achieve alone.


As well as having an instant beautifying effect on text, kerning can also have an effect on the readability of the text. When done well, words just read better.


However, a note of caution! There are many infamous examples on the web of kerning gone wrong, when poorly kerned letters have formed unintended or, in some cases, downright rude, words.


---


### How Do I Apply Kerning?


---


In InDesign, you can adjust kerning from either the **Controls panel** running along the top of the workspace or the**Character panel** (**Window > Type & Tables > Character**).


![what is kerning beginners typography letter-spacing how to indesign](http://nuggetofjoy.com/wp-content/uploads/3-4.jpg)


Select the **Type Tool (T)**, click your cursor to the left or right side of a letter, and increase or decrease the kerning (which is measured in thousandths of an em) by choosing from the default options (which jumps in sequences of 5’s, 10’s, 25’s and 100’s) or typing in a number.


---


# The Beginner’s Guide to Tracking


## In our typography breakdown series, we look at some of the key techniques which have the ability to transform lacklustre text into jaw-dropping typography.


Here, we’re going to find out more about letter-spacing or Tracking, including what it is and how you can adjust letter-spacing to improve your own design work.


---


### What is letter-spacing / Tracking?


---


Tracking is the typographer’s term for letter-spacing. Sometimes confused with [kerning](https://indesignskills.com/tutorials/kerning/) (which is used to adjust spacing between individual letters), tracking adjusts the letter-spacing uniformly over a range of characters.


![what is tracking beginners typography letter-spacing how to indesign](http://nuggetofjoy.com/wp-content/uploads/track1-1-3.jpg)


Tracking affects the visual density of a word, phrase or paragraph. Decreasing the tracking makes the words appear more compact, while increasing tracking increases the amount of white space between letters and words, creating a more airy effect.


---


### Why Do Designers Use Tracking?


---


Designers apply tracking for two main reasons:


- Firstly, when tracking is increased it can improve the readability of text. Letters and words are more visually distinguished from each other, allowing the eye to process them more easily than if characters were pushed closely together.
- Many designers apply tracking to improve the look of typeset text. Increasing or decreasing tracking has the power to reduce the amount of hyphenation in a paragraph, and banish widows (lone words at the end of a paragraph) and orphans (lone words at the top of a page, which should belong on the previous page).


![what is tracking beginners typography letter-spacing how to indesign](http://nuggetofjoy.com/wp-content/uploads/2-1-5.jpg)


In the second image the tracking has been reduced. This pushes all the letters closer together, causing the same number of words to fit onto less lines (which removes the widow ‘eat’).


---


### How Do I Apply Tracking?


---


In InDesign, you can adjust kerning from either the Controls panel running along the top of the workspace or the Character panel (Window > Type & Tables > Character).


Use your Type Tool (T) cursor to either highlight the text or use the Selection Tool (V, Escape) to select the whole text frame\*.


The tracking option is indicated by an ‘A V’ symbol with an arrow sitting below, and is found alongside the other most commonly used text formatting options in the Controls or Character panel. Measured in thousandths of an em, you can either choose a positive (to increase the spacing) or negative (to decrease) value from the drop-down menu, or type in a numeric value in the text box.


![what is tracking beginners typography letter-spacing how to indesign](http://nuggetofjoy.com/wp-content/uploads/3-1-7.jpg)


**\****For a linked sequence of text frames selecting the first text frame will apply the tracking settings to the text flowing across all the frames.*


# The Beginner’s Guide to Leading


## In our typography breakdown series, we look at some of the key techniques which have the ability to transform lacklustre text into jaw-dropping typography.


Here, we’re going to find out more about leading (or line spacing), including what it is and how you can apply it in your own design work.


---


### What is Leading?


---


![what is leading beginners typography line-spacing how to indesign](http://nuggetofjoy.com/wp-content/uploads/Leading-2.jpg)


The definition of leading is: the distance between two baselines of lines of type. The word ‘leading’ originates from the strips of lead hand-typesetters used to use to space out lines of text evenly. The word leading has stuck, but essentially it’s a typographer’s term for line spacing.


---


### Why Do Designers Use Leading?


---


Leading is one of the quickest and simplest tweaks you can do to make your text look instantly better.


![what is leading beginners typography line-spacing how to indesign](http://nuggetofjoy.com/wp-content/uploads/Squashed-2.jpg)


If you’re working in design software like InDesign, the program will set a default leading value whenever you type up more than one line of text. However, this is not usually generous enough, and can make paragraphs look squashed. This works fine if you’re creating a crammed front page for a newspaper, but less well for most other purposes.


Increasing the leading allows the text to breathe and makes it appear instantly more attractive. For readers it has practical advantages too—increasing leading makes text easier to read, and it’s also kinder on reader’s eyes over longer periods of reading.


![what is leading beginners typography line-spacing how to indesign](http://nuggetofjoy.com/wp-content/uploads/Generous-2.jpg)


So if you’re designing a book or magazine layout, increasing your leading will ensure your audience is captive for longer.


---


### How Do I Apply Leading?


---


When working in InDesign, once you’ve created a piece of text using the **Type Tool (T)**, you can adjust the leading from either the **Controls panel** running along the top of the workspace or the **Character panel** (**Window > Type & Tables > Character**). To edit the leading across a whole section of text, either highlight the text or click on the text frame to select it.


![what is leading beginners typography line-spacing how to indesign](http://nuggetofjoy.com/wp-content/uploads/1-10.jpg)


Leading is always positioned below or next to the**Font Size** option. Setting the leading to **Auto** will apply InDesign’s default leading for the font size you currently have applied. You should see this as a minimum value for your leading. Increasing the leading (which is measured in points, pt) will increase the line-spacing across your paragraph.


![what is leading beginners typography line-spacing how to indesign](http://nuggetofjoy.com/wp-content/uploads/one-line-2.jpg)


To apply a particular leading value to just one line of text (e.g. if you want to separate a paragraph visually from a heading positioned above), highlight the line you want to shift downwards and increase the leading.
