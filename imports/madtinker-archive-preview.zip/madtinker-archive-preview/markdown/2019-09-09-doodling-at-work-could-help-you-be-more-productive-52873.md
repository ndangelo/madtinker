---
title: Doodling at work could help you be more productive
slug: doodling-at-work-could-help-you-be-more-productive
date: '2019-09-09'
modified: '2020-02-04'
status: published
wordpress_id: 52873
source_url: https://nuggetofjoy.com/doodling-at-work-could-help-you-be-more-productive/
author: admin
categories:
- 'GN: Basic Drawing'
- Projects
tags: []
migration:
  format: hybrid-markdown
  original_html: original-html/52873.html
  post_css: null
  needs_review: true
---

<div class="post__header-text">
<div class="">
<h2 class="post__deck">Scribbling in the margins of your notebook—which you probably perfected in 7th grade—can have surprising effects on your work.</h2>
</div>
</div>


<div class="post__poster-wrapper post__poster-wrapper--long">
<figure class="poster post-featured__poster"><picture><source media="(max-width: 40em)" sizes="calc(100vw - 20px)" srcset="https://images.fastcompany.net/image/upload/w_300,ar_16:9,c_fill,g_auto,f_auto,q_auto,fl_lossy/wp-cms/uploads/2019/08/p-1-doodling-at-work-could-help-you-be-more-productive.jpg 300w, https://images.fastcompany.net/image/upload/w_638,ar_16:9,c_fill,g_auto,f_auto,q_auto,fl_lossy/wp-cms/uploads/2019/08/p-1-doodling-at-work-could-help-you-be-more-productive.jpg 638w"/><img alt="Doodling at work could help you be more productive" class="-- aligncenter" sizes="calc(0.58333 * (100vw - 40px))" srcset="https://images.fastcompany.net/image/upload/w_562,ar_16:9,c_fill,g_auto,f_auto,q_auto,fl_lossy/wp-cms/uploads/2019/08/p-1-doodling-at-work-could-help-you-be-more-productive.jpg 562w, https://images.fastcompany.net/image/upload/w_937,ar_16:9,c_fill,g_auto,f_auto,q_auto,fl_lossy/wp-cms/uploads/2019/08/p-1-doodling-at-work-could-help-you-be-more-productive.jpg 937w, https://images.fastcompany.net/image/upload/w_1153,ar_16:9,c_fill,g_auto,f_auto,q_auto,fl_lossy/wp-cms/uploads/2019/08/p-1-doodling-at-work-could-help-you-be-more-productive.jpg 1153w"/></picture></figure>
</div>


<div class="post__container post__container--long">
<div class="post__content">
<div class="post__byline"><cite class="post__by">BY SARAH LINDENFELD HALL</cite><span class="post__readTime">5 MINUTE READ</span></div>
<article class="post__article">
<div>
<p>The next time you’re stuck on a project, stymied by a problem, or just stressed out at work, you might want to break out a pen and paper and start doodling. Research shows those random shapes, lines, and figures scrawled on the margins can help memory and cognition, boost creativity, and even just help us relax.</p>
</div>
<div>
<p>In the last decade, those benefits have spurred a growing interest in more sophisticated forms of the practice in classrooms and workplaces. <a href="http://rohdesign.com/">Sketchnoting</a>, <a href="https://www.imagethink.net/what-is-graphic-recording-a-quick-guide/">graphic recording</a>, <a href="https://www.shutterstock.com/blog/dont-think-just-draw-how-infodoodling-enhances-the-creative-process">infodoodling,</a> and other visual thinking applications, which combine words, pictures, symbols, and sketches, all aim to help people process information in a similar way to doodling.</p>
<p>“It’s such a simple tool,” says Sunni Brown, author of <a href="https://www.amazon.com/Doodle-Revolution-Unlock-Power-Differently/dp/1591847036"><em>The Doodle Revolution</em></a><em>, </em>which documents the benefits of doodling and visual language, “but it has so many implications and so many areas where it makes a real difference for people.”</p>
<p>From the earliest age, we’re taught to sit at attention when someone is speaking to us. Scribbling random pictures in our notebooks has long been considered rude or disrespectful—just ask your middle-school history teacher.</p>
<p>But Brown realized something as she traveled the world for work: people doodle everywhere. “I noticed this universal thing happening that seemed to be very useful, powerful, helpful, and natural, but it had no place in any of our institutions,” she says. “There was a disconnect there.”</p>
<div class="teads-inread sm-screen">
<div>
<div class="teads-ui-components-credits"> </div>
</div>
</div>
<h2><strong>‘LIKE HAVING CHOCOLATE’</strong></h2>
<p>Expectations that we only need to listen to learn can make it difficult for some to distill information, especially for visual learners who absorb information best when they can see it. Doodling can help.</p>
<p>When we doodle, according to research, we actually <a href="https://onlinelibrary.wiley.com/doi/abs/10.1002/acp.1561" rel="noopener noreferrer" target="_blank">pay attention and remember more information</a>. The practice can <a href="https://www.sciencealert.com/scientists-find-a-simple-trick-to-help-you-remember-pretty-much-anything" rel="noopener noreferrer" target="_blank">enhance memory</a> in older adults. It can help with <a href="https://www.ncbi.nlm.nih.gov/pmc/articles/PMC2076785/?page=1" rel="noopener noreferrer" target="_blank"><u>mental health</u></a>, and it can make us feel good, too. <a href="https://drexel.edu/now/archive/2017/June/Making-Art-Activates-Brains-Reward-Pathways/" rel="noopener noreferrer" target="_blank">One study</a> measured the blood flow to the brain’s prefrontal cortex, an important part of the brain’s reward pathway, during three different artistic activities: doodling, coloring, and free drawing.</p>
</div>
<div>
<p>“All three activated the brain’s reward pathway,” says lead author Girija Kaimal, an assistant professor at Drexel University’s College of Nursing and Health Professions. “When you engage in drawing, to the brain, that is like having chocolate. It feels good. And doodling actually activated it the most.”</p>
<p>Kaimal says the advantages of doodling are similar to the <a href="https://www.npr.org/2016/04/17/474525392/attention-students-put-your-laptops-away" rel="noopener noreferrer" target="_blank">benefits when we handwrite notes instead of typing them</a>. While doodling, drawing, or physically writing something down, we’re engaging many of our senses and using multiple parts of our brain to synthesize the information.</p>
<p>That process, says Brown, allows you to be present in the moment and opens your mind to new creativity and insights. It’s a tactic scientists, entrepreneurs, and even U.S. presidents have relied on to stimulate new ideas.</p>
<p>“When you hold the same problem in your mind and you start to doodle aspects of it or you do abstractions around it,” she says, “you start to see it differently because different parts of your brain are actually activated.”</p>
<h2><strong>DOODLING AND ITS VARIANTS</strong></h2>
<p>Since writing her book in 2014, Brown has charted a growing interest in doodling in the working world, but especially the more formal forms of visual notetaking, like sketchnoting or graphic recording. “The doodle was the seed, and those other things became the trees and the plants and the garden,” she says.</p>
<p>At Iowa State University, Verena Paepcke-Hjeltness has taught more than 1,000 students about sketchnoting, which combines words with pictures to help students visualize ideas. For engineering students, in particular, the practice, sometimes called “purposeful doodling,” was helpful, she says.</p>
</div>
<div>
<p>“In order for them to visualize a concept, they had to understand it,” says Paepcke-Hjeltness, who recently became an associate professor of practice in design at the University of Texas at Austin. “It took them a little longer to sketchnote when practicing for a test, but they truly understood the content compared to just memorizing it. That was an epiphany moment for them.”</p>
<p>Nora Herting, founder and CEO of <a href="https://www.imagethink.net/" rel="noopener noreferrer" target="_blank">ImageThink</a> and author of <em><u><a href="https://www.amazon.com/Draw-Your-Big-Idea-Creativity/dp/1452152926?tag=fastcomp08-20" rel="noopener noreferrer" target="_blank">Draw Your Big Idea: The Ultimate Creativity Tool for Turning Thoughts Into Action and Dreams into Reality</a>,</u> </em>wouldn’t call what she does doodling. Her company helps businesses chart conversations and complex issues with live interactive drawing events and visual note-taking.</p>
<p>But, just like doodling at the individual level, her work helps groups more easily understand information with pictures and images, and, she says, there’s more awareness of its advantages. A decade ago, when ImageThink launched, she spent a lot of time educating potential clients about why it’s important. Now, she says, “they see the value of it, and they know what it is, and then we have a conversation about how we do it.”</p>
<p>Grace Per Lee, a copywriter and content strategist in Vermont, has understood, at some level, the benefits of doodling most of her life. She started doodling as early as first grade, when her mother remembers getting notes from unhappy teachers about it. Regardless, she’s still at it, marking up her work meeting notes with pictures, maybe of a product or target audience.</p>
<p>“It helps me to not just take in what’s being said and presented,” Per Lee says, “but also connect it with everything else that I know on a deeper level without taking me away from the moment.”</p>
<p>If you’re ready to incorporate doodling into your daily life, follow these tips:</p>
</div>
<div>
<h2><strong>LISTEN FOR THE MAIN POINTS</strong></h2>
<p>In meetings or classes, speakers often repeat their main point multiple times. Capture that, and then start doodling around it. “Even if you took your pen and made one gigantic circle around it and repeated that circle over and over, that in itself, is an act of cementing memory,” Brown says.</p>
<h2><strong>BE MINDFUL</strong></h2>
<p><strong> </strong>Christine Selby, a psychologist, writes in her book, <em><u><a href="https://www.amazon.com/Chilling-Out-Psychology-Relaxation-Everyday/dp/1610697693?tag=fastcomp08-20" rel="noopener noreferrer" target="_blank">Chilling Out: The Psychology of Relaxation</a>,</u> </em>that even just drawing a continuous line that curves and twists across a piece of paper can be enough to relax us.</p>
<p>“There’s all these other meditative and mindfulness aspects of it,” Brown says. “When you’re playing in that space, then it’s really about settling the mind down. . . .  That is very useful for the learning process. When we are trying to take in information and our mind is really busy, then it makes it difficult to absorb content.”</p>
<h2><strong>DON’T AIM FOR PERFECTION</strong></h2>
<p>The pictures on the page don’t have to be sophisticated or elegant. “When you write a word, also draw a picture or draw a shape or put it in a structure,” Brown says. “Just start to give whatever it is that you’re creating another expression, another form, and not just words and numbers. Give it shapes and images and symbols and color and structure, and just see what happens.”</p>
</div>
</article>
</div>
</div>


*Source:* [*https://www.fastcompany.com/90390656/doodling-at-work-could-help-you-be-more-productive*](https://www.fastcompany.com/90390656/doodling-at-work-could-help-you-be-more-productive)
