---
title: The Elements of Art
slug: how-the-elements-of-art-shape-creativity
date: '2020-01-20'
modified: '2020-03-02'
status: published
wordpress_id: 52448
source_url: https://nuggetofjoy.com/how-the-elements-of-art-shape-creativity/
author: admin
categories:
- 'GN: Basic Drawing'
- Projects
tags: []
migration:
  format: hybrid-markdown
  original_html: original-html/52448.html
  post_css: null
  needs_review: true
---

In order to understand any field, it’s important to have a solid foundation from which to grow. For visual art, this means understanding the **elements of art**.


**Line, color, shape, form, value, space, and texture** are the seven core elements of art and they often overlap and inform one another. Whether talking about drawing, painting, sculpture, or design, these components of art all need to be taken into consideration.


## What are the seven elements of art?


### **LINE**


![What Are the 7 Elements of Art?](http://nuggetofjoy.com/wp-content/uploads/elements-of-art-2-18.jpg)

[Stock Photos](https://www.shutterstock.com/photos) from Rabbit Run 11/Shutterstock


**These marks span a distance between two points and can be straight or curved.** In visual art, lines don’t only need to be made with marks and outlines. They can also be implied or abstract. Whether two-dimensional or three-dimensional, there’s no denying that lines have a huge impact on the rest of the elements of art. They can be used to create shape and form, as well as give a sense of depth and structure. Lines are the foundation of drawing and are a powerful tool unto themselves. Using different types of lines—continuous, broken, vertical, jagged, horizontal—drastically changes the psychology of an artwork, impacting the viewer greatly.


### **COLOR**


![What are the 7 Elements of Art?](http://nuggetofjoy.com/wp-content/uploads/famous-flower-paintings-118.jpg)

“Still Life with Irises” by Vincent Van Gogh. 1890.


By working with hue, value, and intensity—three building blocks of colors—artists can tap into a wide range of emotions. There’s nothing that changes an artwork’s emotional impact more than color. Masters like [Van Gogh](https://mymodernmet.com/vincent-van-gogh-life/), [Monet](https://mymodernmet.com/claude-monet-paintings/), and [Toulouse-Lautrec](https://mymodernmet.com/toulous-lautrec-posters/) all expertly manipulated color in their art to provoke different feelings. Color can be used symbolically or to create a pattern. It can be selected for contrast or to set a specific mood. A deep understanding of [color theory](https://mymodernmet.com/basic-color-theory/) helps any artist make better use of the colors they have at their disposal.


### **SHAPE**


![Visual Components of Art](http://nuggetofjoy.com/wp-content/uploads/elements-of-art-38.jpg)

“Simultaneous Counter Composition” (1930) by Theo van Doesburg (Photo: Public domain via [WikiArt](https://www.wikiart.org/en/theo-van-doesburg/simultaneous-counter-composition-1930))


The result of closed lines, shapes are two-dimensional, flat, and only have height and width. Geometric shapes like circles and squares are mathematical and precise, while organic shapes take cues from nature and tend to be curved and abstract. [Henri Matisse](https://mymodernmet.com/henri-matisse-modern-art/)‘s collage art makes great use of organic shapes, while Piet Mondrian is known for relying on geometric shapes in his paintings. Shapes can be used to control how we perceive a composition. For instance, triangles can help draw the eye to a particular point, while circles represent continuity.


### **FORM**


![Art Education - The Elements of Art](http://nuggetofjoy.com/wp-content/uploads/elements-of-art-48.jpg)

Heydar Aliyev Center (2007-2012) by Zaha Hadid. (Photo: [Aleksandr Zykov](https://www.flickr.com/photos/infanticida/25667096538))


When a shape acquires depth and becomes three-dimensional, then it takes on form. Cylinders, pyramids, and spheres are some of the more common forms, though they can also be amorphous. In sculpture, form is of the utmost importance, though it can easily be introduced into drawing and painting using [3D art](https://mymodernmet.com/3d-drawings-anamorphic-art-sandor-vamos/) techniques. Baroque sculptor Bernini was a master of form, carving his sculptures in a way that gave enjoyment from any perspective. Form is also a big consideration in architecture, with acclaimed architects like [Frank Lloyd-Wright](https://mymodernmet.com/frank-lloyd-wright-architecture/), [Zaha Hadid](https://mymodernmet.com/zaha-hadid-architecture/), and [Tadao Ando](https://mymodernmet.com/tadao-ando-architecture/) giving careful consideration to this element in their designs.


### **VALUE**


![7 Elements of Art](http://nuggetofjoy.com/wp-content/uploads/elements-of-art-18.jpg)

“The Tetons and the Snake River” (1942) by Ansel Adams. (Photo: Public domain, [via Wikimedia Commons](https://commons.wikimedia.org/wiki/File:Adams_The_Tetons_and_the_Snake_River.jpg))


Related to color, value is the lightness and darkness of a color. The lightest value is white and the darkest value is black, with the difference between them defined as the contrast. Playing with value can not only change certain forms, but also influence the mood of the artwork. Value is so important that the Italians created a term—[*chiaroscuro*](https://mymodernmet.com/art-history-terms/)—that specifically refers to the use of light and dark in a piece of art. [Baroque](https://mymodernmet.com/baroque-period/) painter Caravaggio was a master of using *chiaroscuro*in his moody oil paintings. Photographer Ansel Adams is another example of an artist who expertly used value to his advantage by using areas of contrast to create interest in his landscape photography.


### **SPACE**


![Atmospheric Perspective](http://nuggetofjoy.com/wp-content/uploads/perspective-drawing-68.jpeg)

(Photo: [Guillaume Briard](https://unsplash.com/photos/lSXpV8bDeMA))


This element of art can be manipulated based on how an artist places lines, shapes, forms, and color. The placement of these other elements creates space. Space can be either positive or negative. Positive space is an area occupied by an object or form, while [negative space](https://mymodernmet.com/negative-space-art/) is an area that runs between, through, around, or within objects. Artists often think about the foreground, middle ground, and background of their artwork, purposefully placing shapes and lines throughout the space to achieve the perfect composition. A sense of depth in two-dimensional works is often achieved by [perspective](https://mymodernmet.com/perspective-drawing/), which itself can rely on lines or colors.


### **TEXTURE**


![Seven Elements of Art](http://nuggetofjoy.com/wp-content/uploads/elements-of-art-58.jpg)

“Pauline Bonaparte as Venus Victrix” (1805-1808) by Antonio Canova. (Photo: Public domain via [Wikipedia](https://commons.wikimedia.org/wiki/File:Paolina_Borghese_(Canova).jpg))


Texture is an element of art that also plays to our sense of touch. It’s defined as a description of the way something feels or looks like it would feel. Sometimes we’re speaking about an actual texture that can be felt, as in the case of Icelandic artist [Hrafnhildur Arnardóttir](https://mymodernmet.com/hrafnhildur-arnardottir-shoplifter-installation-art/), who creates installation art using synthetic hair. Other times, the texture is an implied visual texture that is two-dimensional. Smooth, rough, hard, soft, furry, fluffy, and bumpy are just some different textures that evoke different responses.


For instance, an artist look for a hyperrealistic result would want clouds to appear fluffy, while another artist wishing to subvert conventions might play with texture to create a surreal experience for the viewer. 19th-century sculptor Antonio Canova was a master of this, as exemplified by his portrait of Napoleon’s sister where she’s resting on a cushion that seems so soft and touchable, it’s hard to believe that it’s marble.


*Source: https://mymodernmet.com/elements-of-art-visual-culture/*
