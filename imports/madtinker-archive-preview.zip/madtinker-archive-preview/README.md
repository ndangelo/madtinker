# MadTinker / Nugget of Joy review preview

Open `index.html` to browse 382 static previews. This is a review artifact, not a deployment or final MadTinker integration.

- `markdown/`: original hybrid Markdown conversions (unaltered)
- `posts/`: generated HTML preview pages
- `styles/`: shared and per-post CSS
- `index.json`: searchable post metadata

All original source URLs are retained in front matter and preview pages. Embedded scripts are removed in previews; original Markdown is preserved. Some legacy HTML, WordPress shortcodes, and remotely hosted media require manual verification. Do not publish untrusted HTML without a robust sanitizer.
